Synthetic CT phantom for Bldrs Share tests.
